﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace Todos.Models
{
    class TodoItem
    {

        public string id;

        public string title { get; set; }

        public string description { get; set; }

        public bool completed { get; set; }

        public DateTimeOffset dateString { get; set; }

        public ImageSource image { get; set; }

        public TodoItem(string title, string description)
        {
            this.id = Guid.NewGuid().ToString(); //生成id
            this.title = title;
            this.description = description;
            this.completed = false; //默认为未完成
            this.dateString = DateTimeOffset.Now;
            this.image = new BitmapImage(new Uri("ms-appx:Assets/background.jpg"));
        }

        public TodoItem(string title, string description, DateTimeOffset date, ImageSource source)
        {
            this.id = Guid.NewGuid().ToString(); //生成id
            this.title = title;
            this.description = description;
            this.completed = false; //默认为未完成
            this.dateString = date;
            this.image = source;
        }

    }
}
