﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media;

namespace Todos.ViewModels
{
    class TodoItemViewModel
    {
        private ObservableCollection<Models.TodoItem> allItems = new ObservableCollection<Models.TodoItem>();
        public ObservableCollection<Models.TodoItem> AllItems { get { return this.allItems; } }

        private Models.TodoItem selectedItem = default(Models.TodoItem);
        public Models.TodoItem SelectedItem { get { return selectedItem; } set { this.selectedItem = value; }  }

        public TodoItemViewModel()
        {
            // 加入两个用来测试的item
            this.allItems.Add(new Models.TodoItem("123", "123"));
            this.allItems.Add(new Models.TodoItem("456", "456"));
        }

        public void AddTodoItem(string title, string description, DateTimeOffset date, ImageSource source)
        {
            this.allItems.Add(new Models.TodoItem(title, description, date, source));
        }

        public void RemoveTodoItem(string id)
        {
            // DIY
            for(int i = 0; i < allItems.Count; i++)
            {
                if (allItems[i].id == id)
                {
                    allItems.Remove(allItems[i]);
                    break;
                }
            }

            // set selectedItem to null after remove
            this.selectedItem = null;
        }

        public void UpdateTodoItem(string id, string title, string description, DateTimeOffset date, ImageSource source)
        {
            // DIY
            for(int i = 0; i < allItems.Count; i++)
            {
                if(allItems[i].id == id)
                {
                    allItems[i].title = title;
                    allItems[i].description = description;
                    allItems[i].dateString = date;
                    allItems[i].image = source;
                    break;
                }

            }
            // set selectedItem to null after update
            this.selectedItem = null;
        }

    }
}
